from django.contrib import admin
from .models import Snippet, UserItem, Imagenes, Estados_logicos

# Register your models here.

class UserItem_Admin(admin.ModelAdmin):
	list_display = ('owner','usuario','codigo_chapa','ip_camara')
	search_fields = ('owner','usuario','codigo_chapa','ip_camara')

class Imagenes_Admin(admin.ModelAdmin):
	list_display = ('imagen','ip_camara','time')
	search_fields = ('imagen','ip_camara','time')

class Estados_logicos_Admin(admin.ModelAdmin):
	list_display = ('codigo_chapa','estado')
	search_fields = ('codigo_chapa','estado')

admin.site.register(Snippet)
admin.site.register(UserItem, UserItem_Admin)
admin.site.register(Imagenes, Imagenes_Admin)
admin.site.register(Estados_logicos, Estados_logicos_Admin)