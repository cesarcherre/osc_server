from django.contrib.auth.models import User, Group
from rest_framework import serializers
from seguridad.models import Snippet, UserItem, Imagenes, Estados_logicos

class UserSerializer(serializers.ModelSerializer):
	owner = serializers.CharField(source='owner.username')
	snippets = serializers.PrimaryKeyRelatedField(many=True, queryset=Snippet.objects.all())
	username = serializers.CharField(required=True, max_length=100)
	
	class Meta:
		model = User
		fields = ('id', 'username', 'snippets', 'owner')


class GroupSerializer(serializers.HyperlinkedModelSerializer):
    class Meta:
        model = Group
        fields = ('url', 'name')

class UserItemSerializer(serializers.ModelSerializer):
	owner = serializers.CharField(source='owner.username')
	class Meta:
		model = UserItem
		fields = ('usuario','codigo_chapa', 'ip_camara','owner')

class ImagenesSerializer(serializers.ModelSerializer):
	owner = serializers.ReadOnlyField(source='owner.username')
	ip_camara_name = serializers.ReadOnlyField(source='ip_camara.ip_camara')
	class Meta:
		model = Imagenes
		fields = ('imagen','ip_camara_name', 'time','owner')

class Estados_logicosSerializer(serializers.ModelSerializer):
	class Meta:
		model = Estados_logicos
		fields = ('codigo_chapa','estado')




class Open_doorSerializer(serializers.ModelSerializer):
	class Meta:
		fields = ('ip')

class Door_Serializer(serializers.Serializer):
	info_sensor_puerta = serializers.CharField(max_length=50)

   


class SignUpSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ('username', 'password')
        write_only_fields = ('password',)



#class SnippetSerializer(serializers.Serializer):
	
	#pk = serializers.IntegerField(read_only=True)
	#imagen = serializers.ImageField(max_length=None)
	#title = serializers.CharField(required=False, allow_blank=True, max_length=100)
	#code = serializers.CharField(style={'base_template': 'textarea.html'})
	#linenos = serializers.BooleanField(required=False)
	#language = serializers.ChoiceField(choices=LANGUAGE_CHOICES, default='python')
	#style = serializers.ChoiceField(choices=STYLE_CHOICES, default='friendly')
	#owner = serializers.ReadOnlyField(source='owner.username')
	#class Meta:
		#model = Snippet
		#fields = ('id', 'title', 'code', 'linenos', 'language', 'style','owner','image')
		#owner = serializers.Field(source='owner.username')

	
	#def create(self, validated_data):
		
		#return Snippet.objects.create(**validated_data)

	#def update(self, instance, validated_data):
		
		#instance.title = validated_data.get('title', instance.title)
		#instance.code = validated_data.get('code', instance.code)
		#instance.linenos = validated_data.get('linenos', instance.linenos)
		#instance.language = validated_data.get('language', instance.language)
		#instance.style = validated_data.get('style', instance.style)
		#instance.save()
		#return instance