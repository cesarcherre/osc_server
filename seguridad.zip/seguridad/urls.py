from django.conf.urls import url
from rest_framework.urlpatterns import format_suffix_patterns
from seguridad import views


urlpatterns = [
	url(r'^users/$', views.UserList.as_view()),
	url(r'^users/(?P<pk>[0-9]+)/$', views.UserDetail.as_view()),
    #url(r'^snippets/$', views.SnippetList.as_view()),
    #url(r'^snippets/(?P<pk>[0-9]+)/$', views.SnippetDetail.as_view()),
    url(r'^useritem/$', views.UserItemList.as_view()),
    #url('^useritem/(?P<usuario>.+)/$', views.UserItemList.as_view()),
    url(r'^imagenes/$', views.ImagenesList.as_view()),
    #url('^imagenes/(?P<ip>.+)/$', views.ImagenesList.as_view()),
    #url(r'^open_doors/(?P<ip>.+)/$', views.Open_door.as_view()),
    #url(r'^open_doors/$', views.Open_door.as_view()),

    url(r'^abre_puertas/$', views.open_doors.as_view()),
    url(r'^toma_foto/$', views.take_photo.as_view()),
    url(r'^envia_datos/$', views.data_com.as_view()),
    url(r'^estado_logico/$', views.Estados_logicosList.as_view()),
]

urlpatterns = format_suffix_patterns(urlpatterns)