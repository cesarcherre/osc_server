import django_filters
from rest_framework import filters
from seguridad.models import Snippet, UserItem, Imagenes

class UserItemFilter(django_filters.FilterSet):
	usuario_name  = django_filters.CharFilter(name='usuario__username')
	class Meta:
		model = UserItem
		fields = ('usuario_name','codigo_chapa','ip_camara')

class ImagenesFilter(django_filters.FilterSet):
	ip_camara_name = django_filters.CharFilter(name='ip_camara__ip_camara')
	time_day = django_filters.DateTimeFilter(name='time', lookup_type="gte")
	class Meta:
		model = Imagenes
		fields = ('imagen','ip_camara_name','time_day')


class IsOwnerFilterBackend(filters.BaseFilterBackend):
   
    def filter_queryset(self, request, queryset, view):
        return queryset.filter(owner=request.user)

class IsIpFilterBackend(filters.BaseFilterBackend):
   	
    def filter_queryset(self, request, queryset, view):
    	queryset_1 = UserItem.objects.all()
    	query_1 = queryset_1.filter(owner=request.user)
    	data = query_1.values('ip_camara')
    	#print data
    	queryset = Imagenes.objects.all()
    	query = queryset.filter(ip_camara__ip_camara__in=data)
        return query
