from django.shortcuts import render
from rest_framework import status
from rest_framework.decorators import api_view
from rest_framework.views import APIView
from rest_framework.response import Response
from django.http import HttpResponse
#from django.views.decorators.csrf import csrf_exem
from rest_framework.parsers import JSONParser
from django.contrib.auth.models import User, Group
from rest_framework import viewsets
from seguridad.models import Snippet, UserItem, Imagenes, Estados_logicos
from seguridad.serializers import UserSerializer, GroupSerializer, UserItemSerializer, ImagenesSerializer, Open_doorSerializer, Door_Serializer, Estados_logicosSerializer, SignUpSerializer
from rest_framework import generics
from rest_framework import permissions
from rest_framework import filters
from seguridad.filters import UserItemFilter, ImagenesFilter, IsOwnerFilterBackend, IsIpFilterBackend
from seguridad.permissions import IsOwnerOrReadOnly


from rest_framework.authentication import TokenAuthentication
from rest_framework.permissions import IsAuthenticated





from rest_framework.authtoken.models import Token
from rest_framework.exceptions import ParseError
from rest_framework import status



from django.http import JsonResponse




from permissions import IsAuthenticatedOrCreate


import datetime
import urllib
import os

global datos 
datos = None

global dicc
dicc = {}

"""
class UserViewSet(viewsets.ModelViewSet):
    
    queryset = User.objects.all().order_by('-date_joined')
    serializer_class = UserSerializer


class GroupViewSet(viewsets.ModelViewSet):
    
    queryset = Group.objects.all()
    serializer_class = GroupSerializer
"""

class UserList(generics.ListAPIView):
	queryset =  User.objects.all()
	serializer_class =  UserSerializer

class UserDetail(generics.RetrieveAPIView):
	queryset = User.objects.all()
	serializer_class = UserSerializer


class UserItemList(generics.ListAPIView):
	queryset = UserItem.objects.all()
	serializer_class = UserItemSerializer
	#permission_classes = (permissions.IsAuthenticatedOrReadOnly,)
	permission_classes = (IsAuthenticated,)
	filter_backends = (IsOwnerFilterBackend,)
	#filter_backends = (filters.DjangoFilterBackend,)
	filter_class = UserItemFilter

	
class ImagenesList(generics.ListAPIView):
	#queryset = Imagenes.objects.all()
	serializer_class = ImagenesSerializer
	permission_classes = (IsAuthenticated,)
	#permission_classes = (permissions.IsAuthenticatedOrReadOnly,)
	#filter_backends = (filters.DjangoFilterBackend,)
	#filter_backends = (IsOwnerFilterBackend,)
	#filter_fields = ('imagen','ip_camara_name','time_day')
	#filter_backends = (IsIpFilterBackend,)
	#filter_class = ImagenesFilter
	def get_queryset(self):
		queryset_1 = UserItem.objects.all()
		query_1 = queryset_1.filter(owner=self.request.user)
		data = query_1.values('ip_camara')
		queryset_2 = Imagenes.objects.all()
		queryset = queryset_2.filter(ip_camara__ip_camara__in=data)
		query = self.request.query_params
		
		if 'ip' in query.keys():
			queryset = queryset.filter(ip_camara__ip_camara=query.get('ip'))
		if 'time_day' in query.keys():
			queryset = queryset.filter(time__gt=query.get('time_day'))
		try:
			query_out = queryset
			pass
		except:
			query_out = queryset
			
		return query_out
	


class Estados_logicosList(generics.ListAPIView):
	queryset = Estados_logicos.objects.all()
	serializer_class = Estados_logicosSerializer
	permission_classes = (IsAuthenticated,)

	def get_queryset(self):
		query = self.request.query_params
		query_filter_user = UserItem.objects.all().filter(owner=self.request.user)
		data = query_filter_user.values('codigo_chapa')
		print data
		if 'estado' in query.keys():
			estado = query.get('estado')
			pass
		if 'ip' in query.keys():
			ip_recive = query.get('ip')
			try:
				data_ip = query_filter_user.filter(codigo_chapa=ip_recive).values_list('codigo_chapa').first() #falta autentificarlo por usuario
				if ip_recive == data_ip[0] :
					try:
						r_data = Estados_logicos.objects.get(codigo_chapa=data_ip[0])
						pass
					except:
						r_data = None
					if r_data != None :
						Estados_logicos.objects.filter(codigo_chapa=data_ip[0]).update(estado=estado)
					else :
						Estados_logicos.objects.create(codigo_chapa=data_ip[0], estado=estado)
				pass
			except :
				print 'no se ha podido establecer el estado logico'
				
	

		return self.queryset.filter(codigo_chapa__in = data)
		pass


class open_doors(APIView):

	permission_classes = (IsAuthenticated,)

	def get(self, request, format=None):
		info = []
		query = self.request.query_params
		if 'ip' in query.keys():
			dir_ips = query.get('ip').split(',')
			for x in xrange(0,len(dir_ips)):
				url = 'http://'+dir_ips[x]+'/gpio/1'
				print url
				try:
					response = urllib.urlopen(url)
					info.append(dir_ips[x]+' se activo ')
					pass
				except Exception:
					info.append(dir_ips[x]+' no se activo ')
				pass
			print info
       
		return Response({'state': info, 'state_sensor_door': '0', 'state_sensor_pir': '0',})

class take_photo(APIView):

	def get(self, request, format=None):
		c = 0
		info = []
		query = self.request.query_params
		if 'ip' in query.keys():
			ips = query.get('ip')
			lista = []
			for file in os.listdir("/home/cesar/django_proyect/osc_server/media/imagenes/"):
				if file.endswith(".jpeg"):
					lista.append(int(file[5:len(file)-5]))

			m = sorted(lista) 
		
			try:
				c = int(m[len(m)-1])
				
				pass
			except Exception:
				c = 0
			#print ips
			print c
			f = open('/home/cesar/django_proyect/osc_server/media/imagenes/photo'+str(c+1)+'.jpeg', 'wb')
			imagen_path = 'imagenes/photo'+str(c+1)+'.jpeg'
			try:
				url = 'http://'+str(ips)+'/snapshot.cgi?user=admin&pwd='
				resource = urllib.urlopen(url)
				f.write(resource.read())
				f.close
				print imagen_path
				ipnames = UserItem.objects.all().filter(ip_camara=ips).first()
				print ipnames
				Imagenes.objects.create(ip_camara=ipnames, imagen = 'imagenes/photo'+str(c+1)+'.jpeg')
				info = 'Toma de fotos satifactoria'
			except :
				info = 'ha ocurrido un problema con las ip de camara'
			#ip_datas = UserItem.objects.get(ip_camara=ips)

		return Response({'state': info,})



class data_com(APIView):

	def get(self, request, format=None):
		global dicc
		query = self.request.query_params
		if 'ip' in query.keys():
			ip = query.get('ip')
			if 'dato' in query.keys():
				dicc[ip] = query.get('dato') 
		
			return Response({'datos enviados': dicc,'state sensor door': 0})
		pass

def esp_paralelo(self):
	url = 'http://'+dir_ips[x]+'/gpio/1'
	print url
	try:
		response = urllib.urlopen(url)
		info.append(dir_ips[x]+' se activo ')
		pass
	except Exception:
		info.append(dir_ips[x]+' no se activo ')
		pass
	pass

def open_door(request):

	query = self.request.query_params

	url = 'http://192.168.1.33/gpio/1'

	try:
		response = urllib.urlopen(url)
		return HttpResponse(str(response.read()[25:49-8]))
		pass
	except Exception:
		return HttpResponse("no hay conectado servidor cliente")
		

class Open_door(generics.ListAPIView):

	serializer_class = Door_Serializer

	def get_queryset(self):
		info  = []
		query = self.request.query_params
		if 'ip' in query.keys():
			dir_ips = query.get('ip').split(',')
			#print dir_ips
			for x in xrange(0,len(dir_ips)):
				url = 'http://'+dir_ips[x]+'/gpio/1'
				print url
				try:
					response = urllib.urlopen(url)
					info.append(dir_ips[x]+' se activo ')
					pass
				except Exception:
					info.append(dir_ips[x]+' no se activo ')
				pass
			print info
		initial = {'servo': 'dsd', 'led1': 'dsds', 'led2': 'dsd'}
		return initial

		





class SignUp(generics.CreateAPIView):
    queryset = User.objects.all()
    serializer_class = SignUpSerializer
    permission_classes = (IsAuthenticatedOrCreate,)
		#return queryset

		#return Response(response.data)
#class SnippetList(generics.ListCreateAPIView):
	
	#queryset = Snippet.objects.all()
	#serializer_class = SnippetSerializer
	#permission_classes = (permissions.IsAuthenticatedOrReadOnly,IsOwnerOrReadOnly,)
	
	#def pre_save(self, snip):
		#snip.owner = self.request.user
		#pass

	#def preform_create(self, serializer):
		#serializer.save(owner=self.request.user)
	

	
#class SnippetDetail(generics.RetrieveUpdateDestroyAPIView):
	
	#queryset = Snippet.objects.all()
	#serializer_class = SnippetSerializer
	#permission_classes = (permissions.IsAuthenticatedOrReadOnly,IsOwnerOrReadOnly,)

"""
class JSONResponse(HttpResponse):


	def __init__(self, data, **kwargs):
		content = JSONRenderer().render(data)
		kwargs['content_type'] = 'application/json'
		super (JSONResponse, self).__init__(content,**kwargs)
		pass

def snippet_list(request, format=None):

	if request.method == 'GET':
		snippets = Snippet.objects.all()
		serializer = SnippetSerializer(snippets, many=True)
		return JSONResponse(serializer.data)

	elif request.method == 'POST':
		data = JSONParser().parse(request)
		serializer = SnippetSerializer(data=data)
		if serializer.is_valid():
			serializer.save()
			#return JSONResponse(serializer.data, status=status.HTTP_201_CREATED)
		#return JSONResponse(serializer.errors, status=HTTP_400_BAD_REQUEST)
	pass

def snippet_detail(request, pk, format=None):

	try:
		snippet = Snippet.objects.get(pk=pk)
		pass
	except Snippet.DoesNotExit:
		return HttpResponse(status=404)
			
	if request.method == 'GET':
		serializer = SnippetSerializer(snippet)
		return JSONResponse(serializer.data)

	elif request.method == 'PUT':
		data =  JSONParser.parse(request)
		serializer = SnippetSerializer(snippet, data=data)
		if serializer.is_valid():
			serializer.save()
			return JSONResponse(serializer.data)
		return JSONResponse(serializer.errors, status=400)

	elif request.method == 'DELETE' :
		snippet.delete()
		return HttpResponse(status=204)
		


"""
